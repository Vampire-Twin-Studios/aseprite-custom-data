-- custom-tag-config.lua
-- List of predefined keys for the Custom Tag Data dialog
return {
  { key = "Author", value = "" },
  { key = "Description", value = "" },
  { key = "Category", value = "" }
}
